/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.univc.projeto.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import java.math.BigDecimal;

@Entity
@DiscriminatorValue("CORRENTE")
public class ContaCorrente extends Conta {
    @Override
    public boolean sacar(BigDecimal valor) {
        if (getSaldo().compareTo(valor) >= 0) {
            depositar(valor.negate());
            return true;
        }
        return false;
    }
}