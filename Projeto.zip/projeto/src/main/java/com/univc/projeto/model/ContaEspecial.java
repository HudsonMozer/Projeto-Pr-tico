/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.univc.projeto.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import java.math.BigDecimal;

@Entity
@DiscriminatorValue("ESPECIAL")
public class ContaEspecial extends Conta {
    private BigDecimal limite;

    public BigDecimal getLimite() {
        return limite;
    }

    public void setLimite(BigDecimal limite) {
        this.limite = limite;
    }

    @Override
    public boolean sacar(BigDecimal valor) {
        if (getSaldo().add(limite).compareTo(valor) >= 0) {
            depositar(valor.negate());
            return true;
        }
        return false;
    }
}
