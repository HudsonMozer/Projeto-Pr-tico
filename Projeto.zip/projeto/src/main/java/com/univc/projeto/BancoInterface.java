/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.univc.projeto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class BancoInterface extends JFrame {
    private JTable tabela;
    private DefaultTableModel modelo;
    private JTextField txtTitular, txtSaldo, txtValor;
    private JComboBox<String> cbTipoConta;
    private JButton btnCriar, btnSacar, btnDepositar, btnAtualizar;
    private List<ContaSimulada> contas;

    public BancoInterface() {
        // Configuração inicial da janela
        setTitle("Banco - Sistema");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Lista de contas simuladas (para teste)
        contas = new ArrayList<>();

        // Configuração da tabela
        modelo = new DefaultTableModel(new String[]{"ID", "Titular", "Tipo", "Saldo"}, 0);
        tabela = new JTable(modelo);
        add(new JScrollPane(tabela), BorderLayout.CENTER);

        // Painel para ações
        JPanel painelAcoes = new JPanel(new GridLayout(2, 1));
        JPanel painelSuperior = new JPanel(new GridLayout(2, 4, 10, 10));
        JPanel painelInferior = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));

        // Componentes do painel superior
        txtTitular = new JTextField();
        txtSaldo = new JTextField();
        cbTipoConta = new JComboBox<>(new String[]{"Corrente", "Especial", "Poupança"});
        txtValor = new JTextField();

        painelSuperior.add(new JLabel("Titular:"));
        painelSuperior.add(txtTitular);
        painelSuperior.add(new JLabel("Saldo Inicial:"));
        painelSuperior.add(txtSaldo);
        painelSuperior.add(new JLabel("Tipo de Conta:"));
        painelSuperior.add(cbTipoConta);
        painelSuperior.add(new JLabel("Valor (Sacar/Depositar):"));
        painelSuperior.add(txtValor);

        // Botões
        btnCriar = new JButton("Criar Conta");
        btnSacar = new JButton("Sacar");
        btnDepositar = new JButton("Depositar");
        btnAtualizar = new JButton("Atualizar Saldo");

        painelInferior.add(btnCriar);
        painelInferior.add(btnSacar);
        painelInferior.add(btnDepositar);
        painelInferior.add(btnAtualizar);

        painelAcoes.add(painelSuperior);
        painelAcoes.add(painelInferior);
        add(painelAcoes, BorderLayout.SOUTH);

        // Eventos dos botões
        configurarEventos();

        // Atualizar a tabela
        atualizarTabela();
    }

    private void configurarEventos() {
        // Evento para criar uma conta
        btnCriar.addActionListener(e -> {
            String titular = txtTitular.getText();
            String tipo = (String) cbTipoConta.getSelectedItem();
            BigDecimal saldo;

            try {
                saldo = new BigDecimal(txtSaldo.getText());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Saldo inicial inválido!", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            ContaSimulada conta = new ContaSimulada(titular, tipo, saldo);
            contas.add(conta);
            atualizarTabela();
            JOptionPane.showMessageDialog(this, "Conta criada com sucesso!");
        });

        // Evento para sacar
        btnSacar.addActionListener(e -> {
            int linhaSelecionada = tabela.getSelectedRow();
            if (linhaSelecionada == -1) {
                JOptionPane.showMessageDialog(this, "Selecione uma conta para sacar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                BigDecimal valor = new BigDecimal(txtValor.getText());
                ContaSimulada conta = contas.get(linhaSelecionada);

                if (conta.sacar(valor)) {
                    atualizarTabela();
                    JOptionPane.showMessageDialog(this, "Saque realizado com sucesso!");
                } else {
                    JOptionPane.showMessageDialog(this, "Saldo insuficiente!", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Valor inválido!", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Evento para depositar
        btnDepositar.addActionListener(e -> {
            int linhaSelecionada = tabela.getSelectedRow();
            if (linhaSelecionada == -1) {
                JOptionPane.showMessageDialog(this, "Selecione uma conta para depositar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                BigDecimal valor = new BigDecimal(txtValor.getText());
                ContaSimulada conta = contas.get(linhaSelecionada);
                conta.depositar(valor);
                atualizarTabela();
                JOptionPane.showMessageDialog(this, "Depósito realizado com sucesso!");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Valor inválido!", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Evento para atualizar a tabela
        btnAtualizar.addActionListener(e -> atualizarTabela());
    }

    private void atualizarTabela() {
        modelo.setRowCount(0); // Limpa a tabela
        for (int i = 0; i < contas.size(); i++) {
            ContaSimulada conta = contas.get(i);
            modelo.addRow(new Object[]{i + 1, conta.getTitular(), conta.getTipo(), conta.getSaldo()});
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            BancoInterface tela = new BancoInterface();
            tela.setVisible(true);
        });
    }

    // Classe interna para simular uma conta bancária
    static class ContaSimulada {
        private String titular;
        private String tipo;
        private BigDecimal saldo;

        public ContaSimulada(String titular, String tipo, BigDecimal saldo) {
            this.titular = titular;
            this.tipo = tipo;
            this.saldo = saldo;
        }

        public String getTitular() {
            return titular;
        }

        public String getTipo() {
            return tipo;
        }

        public BigDecimal getSaldo() {
            return saldo;
        }

        public void depositar(BigDecimal valor) {
            saldo = saldo.add(valor);
        }

        public boolean sacar(BigDecimal valor) {
            if (tipo.equals("Especial") || saldo.compareTo(valor) >= 0) {
                saldo = saldo.subtract(valor);
                return true;
            }
            return false;
        }
    }
}