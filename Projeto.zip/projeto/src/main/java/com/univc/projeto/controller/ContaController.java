/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.univc.projeto.controller;

import com.univc.projeto.model.Conta;
import com.univc.projeto.service.ContaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/api/contas")
public class ContaController {
    private final ContaService contaService;

    public ContaController(ContaService contaService) {
        this.contaService = contaService;
    }

    @PostMapping
    public Conta criarConta(@RequestBody Conta conta) {
        return contaService.criarConta(conta);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Conta> buscarConta(@PathVariable Long id) {
        return contaService.buscarConta(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/{id}/sacar")
    public ResponseEntity<String> sacar(@PathVariable Long id, @RequestParam BigDecimal valor) {
        if (contaService.sacar(id, valor)) {
            return ResponseEntity.ok("Saque realizado com sucesso.");
        }
        return ResponseEntity.badRequest().body("Saldo insuficiente.");
    }

    @PostMapping("/{id}/depositar")
    public ResponseEntity<String> depositar(@PathVariable Long id, @RequestParam BigDecimal valor) {
        contaService.depositar(id, valor);
        return ResponseEntity.ok("Depósito realizado com sucesso.");
    }
}
