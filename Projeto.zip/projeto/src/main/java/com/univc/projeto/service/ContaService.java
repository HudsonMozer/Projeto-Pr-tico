/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.univc.projeto.service;

import com.univc.projeto.model.Conta;
import com.univc.projeto.repository.ContaRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Optional;

@Service
public class ContaService {
    private final ContaRepository contaRepository;

    public ContaService(ContaRepository contaRepository) {
        this.contaRepository = contaRepository;
    }

    public Conta criarConta(Conta conta) {
        return contaRepository.save(conta);
    }

    public Optional<Conta> buscarConta(Long id) {
        return contaRepository.findById(id);
    }

    public boolean sacar(Long id, BigDecimal valor) {
        Optional<Conta> conta = contaRepository.findById(id);
        if (conta.isPresent() && conta.get().sacar(valor)) {
            contaRepository.save(conta.get());
            return true;
        }
        return false;
    }

    public void depositar(Long id, BigDecimal valor) {
        contaRepository.findById(id).ifPresent(conta -> {
            conta.depositar(valor);
            contaRepository.save(conta);
        });
    }
}
